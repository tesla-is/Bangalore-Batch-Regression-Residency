import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

mat = np.array([[1, 2], [3, 4]])

mat * mat
mat @ mat

mat.dot(mat)

m = 100
X = np.random.randn(m, 1)
y = 7 * X + 2 + np.random.randn(m, 1) #gaussian noise

plt.plot(X, y)
plt.show()


# This is the line of predictions
theta_0 = 2
theta_1 = 7

plt.scatter(X, y)
plt.show()

X = np.c_[np.ones(m), X]

theta = np.linalg.inv(X.T @ X) @ X.T @ y
theta

# One question has been answered.
# Now we are certain that the normal equation works.




