import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 1. Get the data
dataset = pd.read_excel('blood.xlsx')

# 2. Discovery and Visualization

plt.scatter(dataset.Age, dataset['Systolic Blood Pressure'])
plt.xlabel('Age')
plt.ylabel('Systolic Blood Pressure')
plt.title('Blood Pressure Prediction')
plt.show()

# 3. Data preprocessing ---> Not required

# ML problems begin with the equation f(x) = y
# X is used for feature matrix or basically the input to the model
# y is used for vector of observations basically the output for the model
# If Input and Output is given, ML would be able to deduce the
# rule/function/equation that maps input to output
# We have just seen that in SLR, that rule can be described by a line
# which is known as LOP (best fit line)

X = dataset.iloc[:, 1].values
y = dataset.iloc[:, -1].values
X = X.reshape(-1, 1)

# 4. Select and Train a ML Algo

from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X, y)

# reshape(-1, 1) ---> As many rows as possible but only one col
# reshape(1, -1) ---> As many cols as possible but only one row

# X = X.reshape(-1, 1)
# X = X.reshape(1, -1)

lin_reg.predict([[26]])
lin_reg.predict([[24]])

# From the concepts, we know that if the lop is known.
# it means that the gradient and intercept is known.
# We simply need to solve the eqn of line to get predictions
# Let us verify this

m = lin_reg.coef_
m

c = lin_reg.intercept_
c

# In SLR, for predictions, 
# y = mx + c
# y = b0 + b1.x

# input = 26, 24
c + m * 26
c + m * 24

# What if we want to get multiple predictions simultaneously
# Simply provide the entire feature matrix in the predict()

y_pred = lin_reg.predict(X)

# y ---> vector of observations
# y_pred ---> vector of predictions

# Note: We don't know how SLR works so far.
# Will be covered in a bit

plt.scatter(dataset.Age, dataset['Systolic Blood Pressure'])
plt.plot(X, y_pred, c = "r", label = "Line of Predictions")
plt.xlabel('Age')
plt.legend()
plt.ylabel('Systolic Blood Pressure')
plt.title('Blood Pressure Prediction')
plt.show()




























































